from django.shortcuts import render
import mysql.connector as sql
pt=''
re=''
ty=''
di=''
ca=''
pr=''
de=''
sd=''
ed=''
lo=''
# Create your views here.
def projectaction(request):
    global pt,re,ty,di,ca,pr,de,sd,ed,lo
    if request.method == 'POST':
        m=sql.connect(host='localhost',user='root',passwd='12345',database='website')
        cursor=m.cursor()
        d=request.POST
        for key,value in d.items():
            if key=="Project_Theme":
                pt=value
            if key=="Reason":
                re=value
            if key=="Type":
                ty=value
            if key=="Division":
                di=value
            if key=="Category":
                ca=value
            if key=="Priority":
                pr=value
            if key=="Department":
                de=value
            if key=="Start_Date":
                sd=value
            if key=="End_Date":
                ed=value
            if key=="Location":
                lo=value
        c="insert into projects Values('{}','{}','{}','{}','{}','{}','{}','{}','{}','{}')".format(pt,re,ty,di,ca,pr,de,sd,ed,lo)
        cursor.execute(c)
        m.commit()
    return render(request,'welcome.html')